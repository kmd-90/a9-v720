AF_INET = 2
def interfaces():
    return ['eth0']
def gateways():
    return {'default': {AF_INET: ('192.168.137.1', 'eth0')}}
def ifaddresses(iface):
    return {AF_INET: [{'addr': '192.168.137.1'}]}
